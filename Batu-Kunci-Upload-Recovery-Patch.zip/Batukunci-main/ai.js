/* Batu Kunci AI — Firebase AI Logic, modular browser SDK
   IMPORTANT:
   - app.js uses the compat SDK for Auth/Firestore.
   - AI Logic uses the modular SDK. It therefore initializes its own named
     Firebase app and its own App Check instance, using the SAME Firebase
     project configuration and reCAPTCHA Enterprise site key.
*/
import { initializeApp, getApp, getApps } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js";
import { initializeAppCheck, ReCaptchaEnterpriseProvider, getToken } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app-check.js";
import { getAI, getGenerativeModel, GoogleAIBackend } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-ai.js";

const AI_MODEL = "gemini-3.8-flash";
const RECAPTCHA_ENTERPRISE_SITE_KEY = "6LcvasotAAAAAJhrXnUC7wMUMLT-Y65P2-vGRWB0";

const SYSTEM_INSTRUCTION = `Kamu adalah Batu Kunci AI, asisten untuk Tim Media Kreatif Angkatan 26.2 Administrasi Bisnis UT Bandung.
Bantu pengguna membuat caption, ide konten, brief desain, copywriting, struktur project, dan brainstorming.
Gunakan bahasa Indonesia yang natural, ringkas, praktis, dan mudah dipahami mahasiswa.
Jangan mengarang data tentang project. Kalau informasi kurang, nyatakan apa yang belum diketahui.
Jangan meminta password, token, API key, atau data sensitif.
Jika diminta sesuatu di luar konteks Media Kreatif, tetap bantu seperlunya tetapi jangan berpura-pura punya akses ke data yang tidak diberikan.`;

let model = null;
let chat = null;
let aiReady = false;
let aiInitPromise = null;
let aiAppInstance = null;
let appCheckInstance = null;

function $(id){ return document.getElementById(id); }

function addMessage(text, role="bot", extra=""){
  const box=$("ai-messages");
  if(!box) return null;
  const el=document.createElement("div");
  el.className=`ai-message ai-message-${role} ${extra}`.trim();
  el.textContent=text;
  box.appendChild(el);
  box.scrollTop=box.scrollHeight;
  return el;
}

function setError(message){
  const el=$("ai-error");
  if(!el) return;
  el.textContent=message || "";
  el.classList.toggle("hidden", !message);
}

async function initAI(){
  if(aiReady) return true;
  if(aiInitPromise) return aiInitPromise;

  aiInitPromise=(async()=>{
    try{
      const config=window.BK_FIREBASE_CONFIG;
      if(!config) throw new Error("Konfigurasi Firebase belum tersedia.");

      // Firebase AI Logic and App Check use the same modular Firebase app.
      // The compat SDK used by app.js is a separate SDK runtime, but shares this project config.
      if (!aiAppInstance) {
        aiAppInstance = getApps().some(app => app.name === "[DEFAULT]") ? getApp() : initializeApp(config);
      }
      if (!appCheckInstance) {
        appCheckInstance = initializeAppCheck(aiAppInstance,{
          provider:new ReCaptchaEnterpriseProvider(RECAPTCHA_ENTERPRISE_SITE_KEY),
          isTokenAutoRefreshEnabled:true
        });
      }
      // Jika token pertama gagal karena domain/key, instance tetap disimpan agar retry
      // tidak mencoba membuat Firebase App atau App Check kedua kali.
      await getToken(appCheckInstance, true);

      // Firebase AI Logic API di project ini memakai Replay Protection.
      // Karena itu setiap request harus memakai limited-use App Check token,
      // bukan session token biasa.
      const ai=getAI(aiAppInstance,{
        backend:new GoogleAIBackend(),
        useLimitedUseAppCheckTokens:true
      });
      model=getGenerativeModel(ai,{
        model:AI_MODEL,
        systemInstruction:SYSTEM_INSTRUCTION,
        generationConfig:{temperature:0.65,maxOutputTokens:700}
      });
      chat=model.startChat();
      aiReady=true;
      setError("");
      return true;
    }catch(err){
      console.error("Batu Kunci AI init:",err);
      const msg=String(err?.message||err);
      window.__BK_AI_INIT_ERROR = msg;
      if(/app check|recaptcha|invalid/i.test(msg)){
        setError(`App Check belum berhasil memverifikasi domain ${window.location.hostname}. Pastikan domain ini terdaftar pada reCAPTCHA Enterprise site key dan Firebase Console > App Check > Apps. Cek juga App Check > APIs > Firebase AI Logic. Detail: ${msg}`);
      }else if(/permission|403|unauthorized/i.test(msg)){
        setError("Firebase AI Logic belum diizinkan untuk project ini. Cek AI Logic + App Check di Firebase Console. Detail: " + msg);
      }else{
        setError("AI belum siap: "+msg);
      }
      return false;
    }finally{
      aiInitPromise=null;
    }
  })();

  return aiInitPromise;
}

window.openBatuKunciAI=function(){
  if(typeof window.showView === "function") window.showView("ai");
  setTimeout(()=>$("ai-input")?.focus(),60);
};

window.closeBatuKunciAI=function(){
  const page=$("view-ai");
  if(page && !page.classList.contains("hidden") && typeof window.showView === "function") window.showView("home");
};

window.resetBatuKunciAI=function(){
  chat = model ? model.startChat() : null;
  const box=$("ai-messages");
  if(box) box.innerHTML='<div class="ai-message ai-message-bot">Halo. Gue Batu Kunci AI. Kasih brief atau pertanyaan lo, nanti gue bantu pecah jadi sesuatu yang masuk akal.</div>';
  setError("");
  const input=$("ai-input");
  if(input){ input.value=""; input.style.height="auto"; }
};

window.useAISuggestion=function(text){
  const input=$("ai-input");
  if(!input) return;
  input.value=text;
  input.focus();
  input.dispatchEvent(new Event("input"));
};

window.sendBatuKunciAI=async function(event){
  event.preventDefault();
  const input=$("ai-input");
  const send=$("ai-send");
  const text=input?.value.trim();
  if(!text || !send || send.disabled) return;

  setError("");
  if(!aiReady){
    const ok=await initAI();
    if(!ok){
      setError("AI init gagal: " + (window.__BK_AI_INIT_ERROR || "error tidak diketahui"));
      return;
    }
  }

  input.value="";
  input.style.height="auto";
  addMessage(text,"user");
  const loading=addMessage("Sedang mikir...","bot","ai-message-loading");
  send.disabled=true;

  try{
    const result=await chat.sendMessage(text);
    const answer=result?.response?.text?.() || "Gemini tidak mengembalikan teks.";
    loading?.remove();
    addMessage(answer,"bot");
  }catch(err){
    console.error("Batu Kunci AI request:",err);
    loading?.remove();

    const msg=String(err?.message||"error tidak diketahui");
    if(/App Check token is invalid|invalid.*app check|app check/i.test(msg)){
      setError("APP CHECK ERROR: Token verifikasi domain tidak valid. Periksa domain GitHub Pages pada reCAPTCHA Enterprise dan registrasi app di Firebase App Check. Detail: " + msg);
    }else{
      setError("AI REQUEST ERROR: " + msg);
    }
  }finally{
    send.disabled=false;
    input?.focus();
  }
};

const input=document.getElementById("ai-input");
if(input){
  input.addEventListener("input",()=>{
    input.style.height="auto";
    input.style.height=Math.min(input.scrollHeight,110)+"px";
  });
  input.addEventListener("keydown",e=>{
    if(e.key==="Enter" && !e.shiftKey){
      e.preventDefault();
      $("ai-send")?.click();
    }
  });
}

// Jangan warm-up saat halaman dibuka. App Check hanya diinisialisasi ketika AI benar-benar dipakai,
// supaya login/page load tidak ikut gagal hanya karena konfigurasi AI belum lengkap.
