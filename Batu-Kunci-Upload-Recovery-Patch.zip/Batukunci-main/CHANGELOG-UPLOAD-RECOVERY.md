# Batu Kunci — Upload Recovery Patch

## Perbaikan
- Menambahkan pemeriksaan status resumable upload melalui Apps Script ketika browser kehilangan respons setelah mengirim chunk.
- Jika Drive sudah menerima chunk terakhir, server mengambil metadata file dan aplikasi melanjutkan finalisasi tanpa mengirim ulang seluruh video.
- Jika hanya sebagian chunk diterima, aplikasi melanjutkan dari offset yang dikonfirmasi Drive.
- Finalisasi tidak lagi mengubah permission file satu per satu. File mengikuti izin folder tujuan.

## Catatan keamanan
Folder tujuan `servermdc` harus memakai `Anyone with the link — Viewer`, bukan Editor. Apps Script dijalankan sebagai pemilik/deployer sehingga tetap dapat membuat file di folder yang dimiliki akun deployer. Jangan membagikan folder upload sebagai Editor kepada publik.

## Batas
Maksimum upload tetap 2 GiB per file. Patch ini belum membuktikan upload 2 GiB berhasil pada semua jaringan/perangkat; lakukan tes bertahap dengan file kecil, lalu file besar.
