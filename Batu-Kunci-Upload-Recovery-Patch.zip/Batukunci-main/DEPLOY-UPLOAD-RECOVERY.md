# Deploy Upload Recovery Patch

1. Backup repository dan Apps Script saat ini.
2. Di GitHub, replace `app.js` dari paket ini.
3. Di Apps Script, replace seluruh isi file kode utama dengan `BatuKunci-AppsScript-Build-33-4.gs` dari paket ini. Pertahankan `appsscript.json` dan Advanced Google Service Drive API v3 yang sudah ada.
4. Simpan Apps Script, lalu **Deploy > Manage deployments > Edit** deployment Web App yang dipakai Batu Kunci, pilih **New version**, kemudian Deploy. Pastikan deployment tetap berjalan sebagai akun pemilik Drive.
5. Pada folder upload `servermdc`, set **General access: Anyone with the link — Viewer**. Jangan gunakan Editor untuk akses publik.
6. Tes upload file kecil terlebih dahulu. Pastikan file muncul di folder Drive dan link bisa dibuka. Setelah itu tes video ukuran menengah, baru video besar.

Patch menambahkan aksi `recoverResumableUpload`; karena itu Apps Script wajib di-deploy sebagai versi baru. Jangan hanya mengganti file GitHub.

Jika percobaan lama sudah mencapai 100%, cek folder Drive sebelum mengulang agar tidak membuat duplikat.
